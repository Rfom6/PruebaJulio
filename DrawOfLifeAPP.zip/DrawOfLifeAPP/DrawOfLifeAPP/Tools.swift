//
//  Tools.swift
//  DrawOfLifeAPP
//
//  Created by alumnos on 2/2/17.
//  Copyright © 2017 CRC. All rights reserved.
//

import Foundation
import UIKit

let defaults = NSUserDefaults.standardUserDefaults()

var accepted = true

func showAlertTool(viewController: UIViewController, tittle: String, subtitle: String, type: String){
    
    
    
    switch type as String {
    case "Alert":
        let alertController = UIAlertController(title: tittle, message: subtitle, preferredStyle: .Alert)
        let okAction = UIAlertAction(title: "OK", style: .Default, handler: {(action)-> Void in
            print("ES OK")
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {(action)-> Void in
            print("ES CANCEL")
        })
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        viewController.presentViewController(alertController,animated: true, completion: nil)
   
    default: print("Error")
    
    }

}
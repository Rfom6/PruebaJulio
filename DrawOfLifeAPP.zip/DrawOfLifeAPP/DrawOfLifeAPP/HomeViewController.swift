//
//  ViewController.swift
//  DrawOfLifeAPP
//
//  Created by alumnos on 23/1/17.
//  Copyright © 2017 CRC. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController
{

    @IBOutlet weak var Noticebtn: UIButton!
    
    @IBOutlet weak var imgbtn: UIButton!
    
    @IBOutlet weak var contactBtn: UIButton!
    
    @IBOutlet weak var scoreBtn: UIButton!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(animated: Bool) {
        
        self.navigationItem.title = "Home"
        self.navigationController?.navigationBar.backgroundColor = UIColor.orangeColor()

    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func goToImages(sender: AnyObject) {
    
        let mainstoryBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let vc: UIViewController = mainstoryBoard.instantiateViewControllerWithIdentifier("ImagesViewController") as UIViewController
        
        let modalStyle = UIModalTransitionStyle.FlipHorizontal
        vc.modalTransitionStyle = modalStyle
        
        self.navigationController?.pushViewController(vc, animated: true)
  
    }
    
    @IBAction func goToContact(sender: AnyObject) {
    
        let mainstoryBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let vc: UIViewController = mainstoryBoard.instantiateViewControllerWithIdentifier("ContactViewController") as UIViewController
        
        let modalStyle = UIModalTransitionStyle.FlipHorizontal
        vc.modalTransitionStyle = modalStyle
        
        self.navigationController?.pushViewController(vc, animated: true)

        
        
    }
    
    @IBAction func goToNotices(sender: AnyObject) {
    
        let mainstoryBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let vc: UIViewController = mainstoryBoard.instantiateViewControllerWithIdentifier("NoticesViewController") as UIViewController
        
        let modalStyle = UIModalTransitionStyle.FlipHorizontal
        vc.modalTransitionStyle = modalStyle
        
        self.navigationController?.pushViewController(vc, animated: true)

    
    }
    
    @IBAction func goToScore(sender: AnyObject) {
   
        let mainstoryBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let vc: UIViewController = mainstoryBoard.instantiateViewControllerWithIdentifier("ScoreViewController") as UIViewController
        
        let modalStyle = UIModalTransitionStyle.FlipHorizontal
        vc.modalTransitionStyle = modalStyle
        
        self.navigationController?.pushViewController(vc, animated: true)

        
    }
 
    
}

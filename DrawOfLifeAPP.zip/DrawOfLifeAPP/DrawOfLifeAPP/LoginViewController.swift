//
//  ViewController.swift
//  DrawOfLifeAPP
//
//  Created by alumnos on 19/1/17.
//  Copyright © 2017 CRC. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController
{
    @IBOutlet weak var RegistrarseButton: UIButton!
    @IBOutlet weak var enterBtn: UIButton!
    @IBOutlet weak var UserNametxt: UITextField!
    @IBOutlet weak var UserPasswordtxt: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func pulseRegistrarse(sender: AnyObject)
    {
        goToRegistrarse();
    }
    
    @IBAction func Enter(sender: AnyObject) {
        
        if (UserNametxt.text! == defaults.objectForKey("user") as? String && UserPasswordtxt.text == defaults.objectForKey("password") as? String){
            
            print("Usuario y contraseña coinciden")
            
            goToHome();
            
        }else if (UserNametxt.text! != defaults.objectForKey("user") as? String){
        
        showAlertTool(self, tittle: "Aviso", subtitle: "Datos incorrectos, porfavor compruebe los datos introducidos", type: "Alert")
        
        
        }else if (UserPasswordtxt.text! != defaults.objectForKey("password") as? String){
            
            showAlertTool(self, tittle: "Aviso", subtitle: "Datos incorrectos, porfavor compruebe los datos introducidos", type: "Alert")

        
        }
        
        
        
    }
    
    func goToRegistrarse()
    {
        let vc:RegistrarseViewController = storyboard?.instantiateViewControllerWithIdentifier("RegistrarseViewController") as! RegistrarseViewController;
        let modalStyle = UIModalTransitionStyle.CrossDissolve;
        
        vc.modalTransitionStyle = modalStyle;
        self.presentViewController(vc, animated: true, completion:nil);
        //self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func goToHome()
    {
        let vc:TabBarViewController = storyboard?.instantiateViewControllerWithIdentifier("TabBarViewController") as! TabBarViewController;
        let modalStyle = UIModalTransitionStyle.CrossDissolve;
        
        vc.modalTransitionStyle = modalStyle;
        self.presentViewController(vc, animated: true, completion:nil);
        //self.navigationController?.pushViewController(vc, animated: true)
    }


}


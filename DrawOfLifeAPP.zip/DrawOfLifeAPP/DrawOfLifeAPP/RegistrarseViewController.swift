//
//  RegistrarseViewController.swift
//  DrawOfLifeAPP
//
//  Created by alumnos on 20/1/17.
//  Copyright © 2017 CRC. All rights reserved.
//
import UIKit

class RegistrarseViewController: UIViewController
{
    @IBOutlet weak var backButton: UIButton!
    
    @IBOutlet weak var txtFieldUser: UITextField!
    
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    @IBOutlet weak var txtFieldConfirmPassword: UITextField!
    
    @IBOutlet weak var txtFieldEmail: UITextField!
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func Register(sender: AnyObject) {
  
        if txtFieldUser.text!.isEmpty  {
            accepted = true
            showAlertTool(self, tittle: "AVISO", subtitle: "Usuario vacio", type: "Alert")
        }else{
            accepted = false
        }
        
        if txtFieldPassword.text!.isEmpty {
            accepted = true
            showAlertTool(self, tittle: "AVISO", subtitle: "contraseña vacia", type: "Alert")
        }else{
            accepted = false
        }
        if txtFieldConfirmPassword.text!.isEmpty  {
            accepted = true
            showAlertTool(self, tittle: "AVISO", subtitle: "No has repetido contraseña", type: "Alert")
            
        }else{
        
        accepted = false
            
        }
        if(txtFieldConfirmPassword.text != txtFieldPassword.text){
            accepted = true
            showAlertTool(self, tittle: "AVISO", subtitle: "Las 2 contraseñas no coinciden porfavor repita la contraseña", type: "Alert")
            
            
        }else{
        
        accepted = false
            
        }
        
        if txtFieldEmail.text!.isEmpty  {
            accepted = true
            showAlertTool(self, tittle: "AVISO", subtitle: "campo vacio", type: "Alert")
        }else{
          accepted = false  
        }
        if accepted == false {
            print ("entro")
            
            
            //Esto esta en el Tools que es para que se guarden los valores con una Key
            
            defaults.setValue(txtFieldUser.text!, forKey: "user")
            defaults.setValue(txtFieldPassword.text!, forKey: "password")
            defaults.synchronize()
            
            
            goToHome()
            
        }
    
    
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func goToHome()
    {
        let vc:TabBarViewController = storyboard?.instantiateViewControllerWithIdentifier("TabBarViewController") as! TabBarViewController;
        let modalStyle = UIModalTransitionStyle.CrossDissolve;
        
        vc.modalTransitionStyle = modalStyle;
        self.presentViewController(vc, animated: true, completion:nil);
        //self.navigationController?.pushViewController(vc, animated: true)
    }

    
    
    @IBAction func dismissVC(sender: AnyObject)
    {
        self.dismissViewControllerAnimated(true, completion:nil); //Deshace la presentacion de la vista, volviendo a la vista anterior
    }
}

//
//  ProfileViewController.swift
//  DrawOfLifeAPP
//
//  Created by alumnos on 6/2/17.
//  Copyright © 2017 CRC. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var configBtn: UIButton!
    
    @IBOutlet weak var myScoreBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    override func viewWillAppear(animated: Bool) {
        
        self.navigationItem.title = "Profile"
        self.navigationController?.navigationBar.backgroundColor = UIColor.orangeColor()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func goToConfig(sender: AnyObject) {
   
        let mainstoryBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let vc: UIViewController = mainstoryBoard.instantiateViewControllerWithIdentifier("ProfileConfigViewController") as UIViewController
        
        let modalStyle = UIModalTransitionStyle.FlipHorizontal
        vc.modalTransitionStyle = modalStyle
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func goToMyScore(sender: AnyObject) {
    
        let mainstoryBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let vc: UIViewController = mainstoryBoard.instantiateViewControllerWithIdentifier("ProfileScoreViewController") as UIViewController
        
        let modalStyle = UIModalTransitionStyle.FlipHorizontal
        vc.modalTransitionStyle = modalStyle
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

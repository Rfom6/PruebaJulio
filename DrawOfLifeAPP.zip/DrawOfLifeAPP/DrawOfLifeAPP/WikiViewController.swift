//
//  WikiViewController.swift
//  DrawOfLifeAPP
//
//  Created by alumnos on 2/2/17.
//  Copyright © 2017 CRC. All rights reserved.
//

import UIKit

class WikiViewController: UIViewController {
    
    @IBOutlet weak var myWebView: UIWebView!

    @IBOutlet weak var actIndicator: UIActivityIndicatorView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.actIndicator.hidden = true
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(animated: Bool) {

        self.navigationItem.title = "Wiki"
        self.navigationController?.navigationBar.backgroundColor = UIColor.orangeColor()
        
        actIndicator.hidden = false
        actIndicator.startAnimating()
        
        let url = NSURL(string: "https://proyectostickman.000webhostapp.com/wiki/")
        
        let urlRequest = NSURLRequest(URL: url!)
        myWebView.loadRequest(urlRequest)

        
        let task = NSURLSession.sharedSession().dataTaskWithURL(url!){
            (data, response, error) -> Void in
            
            if error == nil && data != nil{
                
                let URLContent = NSString(data: data!, encoding: NSUTF8StringEncoding) as! String
                print(URLContent)
                
                
                dispatch_async(dispatch_get_main_queue(), {
                    
                    ()-> Void in
                    self.actIndicator.stopAnimating()
                    self.actIndicator.hidden = true
                })
                
                
            }else{
                
                print("Error")
                
                
            }
            
        }
        //Que se ponga a funcionar
        task.resume()

        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
